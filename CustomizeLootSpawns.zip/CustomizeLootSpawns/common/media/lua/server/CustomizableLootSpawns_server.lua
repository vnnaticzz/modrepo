require "Items/ItemPicker"
require "Items/SuburbsDistributions"
require "Items/ProceduralDistributions"
require "Vehicles/VehicleDistributions"

local function removeBaseFromFullType(ItemFullType)
	return string.gsub(ItemFullType, "^Base.", "")
end

local function getSandboxItems(sandboxvar)
	local ztable = {}
	local pattern = "[^ %;]+"

	for match in sandboxvar:gmatch(pattern) do
		table.insert(ztable, match)
	end
	return ztable
end

local function getItemandChance(sandboxvar)
	local ztable = {}
	local pattern = "[^ %:]+"

	for match in sandboxvar:gmatch(pattern) do
		table.insert(ztable, match)
	end
	return ztable
end

local function OnInitGlobalModData()
	local itemIndex = {}
	local containerIndex = {}
	local getAmmo = {}
	local getGuns = {}
	local getSkillBooks = {}
	local getSchematics = {}
	local getLiteratures = {}
	
	local items = getAllItems();
	for i = 0, items:size()-1, 1 do
		local testItem = items:get(i)
		if testItem then
			local displayCategory = testItem:getDisplayCategory()
			local staticModel = testItem:getStaticModel() or nil
			local teachedRecipes = testItem:getTeachedRecipes() or nil
			local getLuaCreate = testItem:getLuaCreate() or nil
			if displayCategory == "Ammo" then
				print("[CustomizableLootSpawns] Ammo Item found! - " .. testItem:getFullName())
				table.insert(getAmmo, testItem:getFullName())
			end
			if displayCategory == "SkillBook" and not teachedRecipes and not getLuaCreate then
				print("[CustomizableLootSpawns] Skill Book found! - " .. testItem:getFullName())
				table.insert(getSkillBooks, testItem:getFullName())
			end
			if displayCategory == "SkillBook" and getLuaCreate then
				print("[CustomizableLootSpawns] Schematic found! - " .. testItem:getFullName())
				table.insert(getSchematics, testItem:getFullName())
			end
			if displayCategory == "Literature" then
				print("[CustomizableLootSpawns] Literature found! - " .. testItem:getFullName())
				table.insert(getLiteratures, testItem:getFullName())
			end
			--print("check item: ", testItem:getFullType())
			testItemTags = testItem:getTags()
			for j=0, testItemTags:size()-1 do
				local tag = testItemTags:get(j);
				if tag then
					if tag == "Ammo" then
						print("[CustomizableLootSpawns] Ammo Item found! - " .. testItem:getFullName())
						table.insert(getAmmo, testItem:getFullName())
					elseif tag == "Firearm" then
						print("[CustomizableLootSpawns] Gun Item found! - " .. testItem:getFullName())
						table.insert(getGuns, testItem:getFullName())
					end
				end
			end
		end
	end

	for containerName, containerData in pairs(ProceduralDistributions.list) do
		if containerData.items then
			for i = 1, #containerData.items, 2 do
				local itemName = containerData.items[i]
				itemIndex[itemName] = itemIndex[itemName] or {}
				table.insert(itemIndex[itemName], { container = containerName, type = "items" })
			end
		end

		if containerData.junk and containerData.junk.items then
			for i = 1, #containerData.junk.items, 2 do
				local itemName = containerData.junk.items[i]
				itemIndex[itemName] = itemIndex[itemName] or {}
				table.insert(itemIndex[itemName], { container = containerName, type = "junk" })
			end
		end

		containerIndex[containerName] = {
			rolls = containerData.rolls, 
			items = {}
		}

		if containerData.items then
			for i = 1, #containerData.items, 2 do
				local itemName = containerData.items[i]
				table.insert(containerIndex[containerName].items, itemName)
			end
		end
	end

	local function yeetItem(item)
		local itemName = item
		if itemIndex[itemName] then
			for j=1,#itemIndex[itemName] do
				containerInfo = itemIndex[itemName][j]
				containerJunk = ""
				local itemDistro = ProceduralDistributions.list[containerInfo.container][containerInfo.type]
				if containerInfo.type == "junk" then
					containerJunk = ".items"
					itemDistro = ProceduralDistributions.list[containerInfo.container][containerInfo.type]["items"]
				end
				for k=#itemDistro,1,-1 do
					if itemDistro[k] == itemName then
						table.remove(itemDistro, k)
						table.remove(itemDistro, k)
						--print("Removing " .. itemName .." from ProceduralDistributions.list."..containerInfo.container.."."..containerInfo.type..containerJunk)
					end
				end
			end
		end
	end

	local function findItem(item)
		local itemName = item
		if itemIndex[itemName] then
			for i=1,#itemIndex[itemName] do
				containerInfo = itemIndex[itemName][i]
				containerJunk = ""
				if containerInfo.type == "junk" then
					containerJunk = ".items"
				end
				--print("Found " .. itemName .." from ProceduralDistributions.list."..containerInfo.container.."."..containerInfo.type..containerJunk)
			end
		else
			print(itemName .. " not found!")
		end
	end

	local function modifyItemWeight(itemName, multiplier)
		if itemIndex[itemName] then
			local processedContainers = {}
			for j=1, #itemIndex[itemName] do
				containerInfo = itemIndex[itemName][j]
				local containerName = containerInfo.container
				if not processedContainers[containerName] then
					local containerData = ProceduralDistributions.list[containerName]
					if containerInfo.type == "items" then
						for i = 1, #containerData.items, 2 do
							if containerData.items[i] == itemName then
								containerData.items[i+1] = containerData.items[i+1] * multiplier
								--print("Modifying " .. itemName .. " weight to: " .. containerData.items[i+1] .. " from ProceduralDistributions.list."..containerInfo.container.."."..containerInfo.type)
							end 
						end
					elseif containerInfo.type == "junk" then
						for i = 1, #containerData.junk.items, 2 do
							if containerData.junk.items[i] == itemName then
								containerData.junk.items[i+1] = containerData.junk.items[i+1] * multiplier
								--print("Modifying " .. itemName .. " weight to: " .. containerData.junk.items[i+1] .. " from ProceduralDistributions.list."..containerInfo.container.."."..containerInfo.type..".items")
							end
						end
					end
					processedContainers[containerName] = true
				end
			end
		end
	end
	
	local vanillaGunsBool = SandboxVars.SpawnChanceModifier.vanillaGunsBool
	local vanillaGunsEnum = SandboxVars.SpawnChanceModifier.vanillaGunsEnum
	local vanillaGunsMod = vanillaGunsEnum / 5
	if vanillaGunsEnum > 5 then
		vanillaGunsMod = (vanillaGunsEnum-5)*2
	end
			
	if vanillaGunsBool then
		for i=1,#getGuns do
			modifyItemWeight(getGuns[i], vanillaGunsMod)
			modifyItemWeight(removeBaseFromFullType(getGuns[i]), vanillaGunsMod)
		end
	end
	
	local vanillaAmmoBool = SandboxVars.SpawnChanceModifier.vanillaAmmoBool
	local vanillaAmmoEnum = SandboxVars.SpawnChanceModifier.vanillaAmmoEnum
	local vanillaAmmoMod = vanillaAmmoEnum / 5
	if vanillaAmmoEnum > 5 then
		vanillaAmmoMod = (vanillaAmmoEnum-5)*2
	end
	if vanillaAmmoBool then
		for i=1,#getAmmo do
			modifyItemWeight(getAmmo[i], vanillaAmmoMod)
			modifyItemWeight(removeBaseFromFullType(getAmmo[i]), vanillaAmmoMod)
		end
	end
	
	local vanillaSkillBookBool = SandboxVars.SpawnChanceModifier.vanillaSkillBookBool
	local vanillaSkillBookEnum = SandboxVars.SpawnChanceModifier.vanillaSkillBookEnum
	local vanillaSkillBookMod = vanillaSkillBookEnum / 5
	if vanillaSkillBookEnum > 5 then
		vanillaSkillBookMod = (vanillaSkillBookEnum-5)*2
	end
	if vanillaSkillBookBool then
		for i=1,#getSkillBooks do
			modifyItemWeight(getSkillBooks[i], vanillaSkillBookMod)
			modifyItemWeight(removeBaseFromFullType(getSkillBooks[i]), vanillaSkillBookMod)
		end
	end
	
	local vanillaSchematicBool = SandboxVars.SpawnChanceModifier.vanillaSchematicBool
	local vanillaSchematicEnum = SandboxVars.SpawnChanceModifier.vanillaSchematicEnum
	local vanillaSchematicMod = vanillaSchematicEnum / 5
	if vanillaSchematicEnum > 5 then
		vanillaSchematicMod = (vanillaSchematicEnum-5)*2
	end
	if vanillaSchematicBool then
		for i=1,#getSchematics do
			modifyItemWeight(getSchematics[i], vanillaSchematicMod)
			modifyItemWeight(removeBaseFromFullType(getSchematics[i]), vanillaSchematicMod)
		end
	end
	
	local vanillaLiteratureBool = SandboxVars.SpawnChanceModifier.vanillaLiteratureBool
	local vanillaLiteratureEnum = SandboxVars.SpawnChanceModifier.vanillaLiteratureEnum
	local vanillaLiteratureMod = vanillaLiteratureEnum / 5
	if vanillaLiteratureEnum > 5 then
		vanillaLiteratureMod = (vanillaLiteratureEnum-5)*2
	end
	if vanillaLiteratureBool then
		for i=1,#getLiteratures do
			modifyItemWeight(getLiteratures[i], vanillaLiteratureMod)
			modifyItemWeight(removeBaseFromFullType(getLiteratures[i]), vanillaLiteratureMod)
		end
	end
	
	local yeetBool = SandboxVars.SpawnChanceModifier.yeetBool
	local yeetItems = getSandboxItems(SandboxVars.SpawnChanceModifier.yeetItems)
	if yeetBool and #yeetItems > 0 then
		for i=1,#yeetItems do
			yeetItem(yeetItems[i])
			yeetItem(removeBaseFromFullType(yeetItems[i]))
		end
	end
	
	local modifyBool = SandboxVars.SpawnChanceModifier.modifyBool
	local modifyItems = getSandboxItems(SandboxVars.SpawnChanceModifier.modifyItems)
	if modifyBool and #modifyItems > 0 then
		for i=1,#modifyItems do
			local item_and_chance = getItemandChance(modifyItems[i])
			modifyItemWeight(item_and_chance[1], item_and_chance[2])
			modifyItemWeight(removeBaseFromFullType(item_and_chance[1]), item_and_chance[2])
		end
	end
	ItemPickerJava.Parse()
end
Events.OnInitGlobalModData.Add(OnInitGlobalModData)